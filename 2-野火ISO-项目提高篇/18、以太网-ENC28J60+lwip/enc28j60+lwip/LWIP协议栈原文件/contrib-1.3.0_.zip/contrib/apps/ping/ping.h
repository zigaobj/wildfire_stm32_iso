#ifndef __PING_H__
#define __PING_H__

void ping_init(void);

#endif /* __PING_H__ */
